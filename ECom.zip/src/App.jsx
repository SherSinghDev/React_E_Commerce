import React from 'react'
import Header from './Components/Header'
import "./App.css"
import Products from './Components/pages/Products'
import ProductDetails from './Components/pages/ProductDetails'
import Cart from './Components/pages/Cart'
import { BrowserRouter, Routes, Route } from 'react-router-dom'

function App() {
  return (
    <>
      {/* <Products />
      <ProductDetails />
      <Cart /> */}


      <BrowserRouter>
        <Header />
        <Routes>
          <Route path='/' Component={Products} />
          <Route path='/productdetail' Component={ProductDetails} />
          <Route path='/cart' Component={Cart} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App