import React from 'react'

function Header() {
    function themeChanger(e) {
        document.querySelector("body").classList.toggle("light")
        let label = e.target.nextElementSibling

        if (label.innerText == "Light Mode") {
            label.innerText = "Dark Mode"
        }
        else {
            label.innerText = "Light Mode"
        }



    }
    return (
        <>
            <header>
                <div className="navbar">
                    <div className="logo"><span>E</span>Company</div>
                    <div className="top-search-box">
                        <div className="btn-group">
                            <button type="button" className="btn btn-secondary dropdown-toggle filter-btn" data-bs-toggle="dropdown" aria-expanded="false">
                                All
                            </button>
                            <ul className="dropdown-menu">
                                <li><a className="dropdown-item" href="#">Action</a></li>
                                <li><a className="dropdown-item" href="#">Another action</a></li>
                                <li><a className="dropdown-item" href="#">Something else here</a></li>
                                <li><hr className="dropdown-divider" /></li>
                                <li><a className="dropdown-item" href="#">Separated link</a></li>
                            </ul>
                        </div>
                        <input type="text" name="" className='border border-dark' id="" placeholder='Search Your Favourite Product' />
                        <button className='btn btn-primary px-3 search-btn'><i className="fa-solid fa-magnifying-glass"></i></button>

                    </div>
                    <div className="cart-btn">
                        <i className="fa-solid fa-cart-shopping me-2"></i> Cart
                    </div>

                    <div className="form-check form-switch theme-changer">
                        <input className="form-check-input" onClick={themeChanger} type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                        <label class="form-check-label" for="flexSwitchCheckDefault">Dark Mode</label>
                    </div>
                </div>

            </header>
        </>
    )
}

export default Header