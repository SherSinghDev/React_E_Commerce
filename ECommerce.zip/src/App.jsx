import React from 'react'
import Header from './Components/Header'
import "./App.css"
import Products from './Components/pages/Products'

function App() {
  return (
    <>
      <Header />
      <Products/>
    </>
  )
}

export default App