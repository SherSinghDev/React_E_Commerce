let allProductsData = [
    {
        id: 1,
        img: "https://i.pinimg.com/236x/05/29/69/0529690a8979471f84e3addfe8ad8955.jpg",
        name: "Allen Solly Men's Polo T-Shirt",
        ratings: 4,
        price: "$49.00",
        description: "A nice tshirt for sports and casuals",
    },
    {
        id: 2,
        img: "https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?cs=srgb&dl=pexels-bertellifotografia-2905238.jpg&fm=jpg",
        name: "Bag",
        ratings: 5,
        price: "$30.00",
        description: "A suitable bag for tracking and travelling",
    },
    {
        id: 3,
        img: "https://myborosil.com/cdn/shop/files/my-borosil-stainless-steel-bottles-trek-black-personalise-32329717710986.gif?v=1717398407",
        name: "Borosil Trek Black Personalise",
        ratings: 5,
        price: "$40.00",
        description: "A isolated bottle with custom name",
    },
    {
        id: 4,
        img: "https://static.nike.com/a/images/t_PDP_1280_v1/f_auto,q_auto:eco/99486859-0ff3-46b4-949b-2d16af2ad421/custom-nike-dunk-high-by-you-shoes.png",
        name: "Nike Dunk High By You Custom Men's Shoes",
        ratings: 5,
        price: "$45.00",
        description: "Name is enough as it's a nike",
    },
    {
        id: 5,
        img: "https://assets.ajio.com/medias/sys_master/root/20240716/a9uS/6696b04a6f60443f31522c1b/-473Wx593H-467290457-grey-MODEL.jpg",
        name: "Men Joggers with Flap Pockets",
        ratings: 4,
        price: "$25.00",
        description: "A casual jogger for daily wears",
    },
    {
        id: 6,
        img: "https://images-cdn.ubuy.co.in/6484ac96c913a5555e0f5648-2021-men-039-s-watches-top-brand.jpg",
        name: "Quartz Watch Sports",
        ratings: '5',
        price: "$59.00",
        description: "2025 Men's Watches Top Brand Luxury Men Wrist Watch Leather Quartz Watch Sports",
    },
]

export default allProductsData